How to use

```bash
git clone https://github.com/naga3/docker-lamp.git
cd docker-lamp/
docker-compose up -d
```
